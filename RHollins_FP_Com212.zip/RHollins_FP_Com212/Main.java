package game;

public class Main {
	public static void main(String [] args) {//main function
		Game game = new Game();
		game.start();
	}

}
